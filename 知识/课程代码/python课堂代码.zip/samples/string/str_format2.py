name = 'jcy'
height = 170
print('my name is %s, and I am %scm tall' % (name, height))

print('my name is {}, and I am {}cm tall'.format(name, height))

print("myName is %s" % "jack")
print("myName is %s, I'm %d years old" % ("jack", 20))
