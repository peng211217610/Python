vs = [('Jack',8756),('Patrick',10000)]

fs = '''
%s salary: %d $
%s salary: %d $
'''

print(fs % (vs[0][0], vs[0][1], vs[1][0], vs[1][1]))
