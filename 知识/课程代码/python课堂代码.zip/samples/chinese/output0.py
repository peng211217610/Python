print('中文')
