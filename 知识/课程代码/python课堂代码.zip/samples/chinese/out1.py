#中文
print('abc')
