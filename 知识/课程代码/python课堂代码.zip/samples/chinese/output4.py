# coding=utf-8
a = '我们这时候'

fh = open('file1','w')
fh.write(a)
fh.close()
