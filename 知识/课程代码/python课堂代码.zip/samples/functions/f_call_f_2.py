
def foo():
    print 'in foo()'
    bar()

def bar():
    print 'in bar()'

foo()