def foo2(a,b):
    print (a*3 + b*5) / 23
foo2(3,4)
foo2(a=3,b=4)
foo2(b=4,a=3)
foo2(3,b=4)
#foo2(a=3,4)