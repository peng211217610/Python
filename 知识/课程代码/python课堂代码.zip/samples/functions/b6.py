def func1():
    print('hello')


def func2():
    return 'hello'

a = func1()
b = func2()
print('a 结果是:' , a)
print('--------------------')
print('b 结果是:' , b)


