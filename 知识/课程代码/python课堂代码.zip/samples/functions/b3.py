def foo(a,b):
    print(a,b)
    a = 3
    b = 4
    print( a,b)

a = 1
b = 2
foo(a,b)

print(a,b)