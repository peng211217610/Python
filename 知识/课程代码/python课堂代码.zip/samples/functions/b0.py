def playfootball():
    print("拿起足球")
    print("来到球场上")
    print("分成两队")
    print("设法把球踢进对方球门")

print(playfootball)
print(type(playfootball))

# playfootball()