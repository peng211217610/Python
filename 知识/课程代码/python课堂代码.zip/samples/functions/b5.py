def func1():
    print('hello')


def func2():
    return 'hello'


print(func1())
print('--------------------')
print(func2())


