var1 = 2

if var1 > 1:
    print('is var1 >1 ?')
    print('yes')

print('continue to do')
