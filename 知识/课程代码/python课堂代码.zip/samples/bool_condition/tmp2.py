var1 = 0

if var1 > 1:
    print('is var1 >1 ?')
    print('yes')
else:
    print('is var1 >1 ?')
    print('no')


print('continue to do')
