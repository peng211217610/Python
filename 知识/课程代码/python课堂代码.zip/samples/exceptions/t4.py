try:
    ohmy
except NameError as e:
    print(type(e))
    print('handle NameError:', e)

