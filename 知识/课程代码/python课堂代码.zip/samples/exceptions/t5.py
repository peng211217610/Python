try:
    ohmy
    4/0
except Exception as e:
    print('handle unkown exception:', e)

print('结尾')