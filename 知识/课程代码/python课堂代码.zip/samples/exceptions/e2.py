b = [1,2]
c = b[2]
print(c + 39)

