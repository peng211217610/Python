a = 8956  / 0
print(a)
