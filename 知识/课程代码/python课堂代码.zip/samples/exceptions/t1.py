while True:
    num = input('input a number:')
    print('10000 / %s = %s' % (num, 10000.0 / int(num)))
