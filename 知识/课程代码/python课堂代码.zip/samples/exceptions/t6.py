import traceback
try:
    ohmy
except :
    print('handle unkown exeption\n' +
          traceback.format_exc())


