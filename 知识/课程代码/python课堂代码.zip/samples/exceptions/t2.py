try:
    b = 4/0
    print('abc')
except ZeroDivisionError:
    print('handle ZeroDivisionError')

print('结尾处')
