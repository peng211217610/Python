a1 = 4

print(a1)
