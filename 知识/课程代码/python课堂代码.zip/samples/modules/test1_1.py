import calc as c

c.calc_s_c(20)

print(c.var1)
