print('***  in test1  begin *** ')
import calc

print(type(calc))
print(type(calc.calc_s_c))

calc.calc_s_c(20)

print(calc.var1)

print('***  in test1  end *** ')