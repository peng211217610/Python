from . import Analog
Analog.dial()