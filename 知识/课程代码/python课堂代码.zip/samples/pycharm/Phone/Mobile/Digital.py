from pycharm.common_util import HOST_NAME
import lib99

print(HOST_NAME)

