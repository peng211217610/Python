from pycharm.common_util import HOST_NAME

print(HOST_NAME)
