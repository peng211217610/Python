import time
exp = input('请输入表达式:')
ret = eval(exp)
print(ret)