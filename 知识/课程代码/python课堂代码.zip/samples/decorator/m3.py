def sayHello():
    print ("hello")

def sayGoodbye():
    print ("goodbye")

print(f"m3 name is " + __name__)

if __name__ == "__main__":
    print ('exec testing')
    sayHello()
    sayGoodbye()
