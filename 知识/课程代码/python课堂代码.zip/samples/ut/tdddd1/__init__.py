

def setUpModule():
    print('td1 setup module')

def tearDownModule():
    print('td1 teardown module')