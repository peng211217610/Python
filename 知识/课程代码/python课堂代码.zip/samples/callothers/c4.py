import os
ret = os.system('dir sdfsdfsdfsd')
print(ret)
