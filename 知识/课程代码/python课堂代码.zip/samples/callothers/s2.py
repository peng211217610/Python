from subprocess import  Popen
popen = Popen(
        args='mspaint e:\\13.jpg',
        shell=True
    )
print('done')

