import os
os.system(r'mspaint d:\1.jpg')
print('after call')
