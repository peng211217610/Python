# number = raw_input('input number\n')
# print int(number)*3

import time
time.sleep(3)
print 'ok'