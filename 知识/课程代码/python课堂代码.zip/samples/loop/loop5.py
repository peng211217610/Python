students = ('Mike', 'Jack', 'Mary', 'Pat','Will','Lisa')
for one in students:
    print(one)

