students = ['Mike', 'Jack', 'Mary', 'Pat','Will','Lisa']

idx = 0
while idx < len(students):
    print(students[idx])
    idx += 1