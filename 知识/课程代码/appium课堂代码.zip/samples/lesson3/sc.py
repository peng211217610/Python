import os
os.system('adb shell screencap /sdcard/screen3.png && adb pull /sdcard/screen3.png')