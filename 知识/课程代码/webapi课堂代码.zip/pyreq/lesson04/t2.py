# coding=utf8

name = '小张'

def eat():
    print(f'{name},该吃饭了')

def go():
    print(f'{name},该出发了')

def sleep():
    print(f'{name},该睡觉了')

def read():
    print(f'{name},该看书了')


eat()
go()
sleep()
read()