# coding=utf8

def eat():
    print('小明, 该吃饭了')

def go():
    print('小明，该出发了')

def sleep():
    print('小明，该睡觉了')

def read():
    print('小明，该看书了')

eat()
go()
sleep()
read()