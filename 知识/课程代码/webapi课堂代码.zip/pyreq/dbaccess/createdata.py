count = 10000

with open('courses1.data','w',encoding='utf8') as f:
    for i in range(count):
        f.write(f"'测试课程{i:07d}', '测试课程{i:07d}',{i}\n")
