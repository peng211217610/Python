host = 'ci.ytesting.com'  # 'ci.ytesting.com'  '192.168.0.104'
user="songqin"
passwd="songqin"
dbname="plesson"

import MySQLdb

# 返回一个Connection 对象，代表了对数据库的一个连接
connection = MySQLdb.connect(host=host,
                     user=user,
                     passwd=passwd,
                     db=dbname,
                     charset = "utf8")
                     
# 防止select 缓存数据
connection.autocommit(True)

# 返回一个cursor对象,中文叫游标
c = connection.cursor()

# 执行一个获取 sq_course 表中所有记录的 sql 语句
sql = "SELECT * FROM sq_course"
c.execute(sql)


numrows = c.rowcount
print("we have %s rows ..." % numrows)

# 获取 每行数据了
# 想象有个游标，每获取一次，游标都会移到后面一条记录

for x in range(numrows):
    # 返回的是一个元组，里面每个元素代表一个字段
    row = c.fetchone()
    print(row)






