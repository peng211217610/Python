import requests
import pprint

# 3个参数，根据参数来发送相应的消息
def add_course(name,desc,displayidx):
    payload = {
        'action': 'add_course',
        # 格式化字符串的方式来构造消息
        'data':'''
        {
          "name":"%s",
          "desc":"%s",
          "display_idx":"%s"
        }''' % (name,desc,displayidx)

    }
    # data参数 就是构造消息体的
    response = requests.post("http://localhost/api/mgr/sq_mgr/",
                             data=payload)

    # 获取结果，返回给调用者
    retDict = response.json()
    # 打印出结果
    print(retDict)
    return retDict


def list_course():

    params = {
        'action':'list_course',
        'pagenum':'1', 'pagesize':20
    }
    response = requests.get("http://localhost/api/mgr/sq_mgr/",
                            params=params)
    # 获取结果，返回给调用者
    retDict = response.json()
    pprint.pprint(retDict)

    # 获取结果，返回给调用者
    return retDict


host = '192.168.1.104'  # 'ci.ytesting.com'
user="songqin"
passwd="songqin"
dbname="plesson"

import MySQLdb


connection = MySQLdb.connect(host=host,
                     user=user,
                     passwd=passwd,
                     db=dbname,
                     charset = "utf8")

# 返回一个cursor对象
c = connection.cursor()

# 执行一个获取 sq_course 表中所有记录的 sql 语句
c.execute("""SELECT * FROM sq_course ORDER BY id DESC LIMIT 1""")

row = c.fetchone()
print(row)
rowid = row[0]

from random import randint

addcoursename = f'java{randint(1,30000)}'
retDict = add_course(addcoursename,'java语言','2')
assert retDict['retcode'] == 0

connection.commit()



# 执行一个获取 sq_course 表中所有记录的 sql 语句
c.execute("""SELECT * FROM sq_course ORDER BY id DESC LIMIT 1""")

row = c.fetchone()
print(row)
newrowid = row[0]
coursename = row[1]
desc = row[2]
displayidx = row[3]

assert  newrowid > rowid
assert  coursename == addcoursename
assert  desc == 'java语言'
assert  displayidx == 2

print('\n========= test case pass =============')
