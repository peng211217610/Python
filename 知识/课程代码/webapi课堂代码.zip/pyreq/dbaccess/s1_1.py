host = '192.168.0.105'  # 'ci.ytesting.com'
user="songqin"
passwd="songqin"
dbname="plesson"

import MySQLdb


connection = MySQLdb.connect(host=host,
                     user=user,
                     passwd=passwd,
                     db=dbname,
                     charset = "utf8")
                     
# 防止select 缓存数据
connection.autocommit(True)

# 返回一个cursor对象
c = connection.cursor()

# 执行一个获取 sq_course 表中所有记录的 sql 语句
c.execute("""SELECT * FROM sq_course""")


numrows = c.rowcount
print("we have %s rows ..." % numrows)

data = c.fetchmany(2)
print(data)


# data = c.fetchall()
# print(data)




