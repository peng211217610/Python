import MySQLdb


host = 'ci.ytesting.com'  # 'ci.ytesting.com'，'192.168.0.105'
user="songqin"
passwd="songqin"
dbname="plesson"


connection = MySQLdb.connect(host=host,
                     user=user,
                     passwd=passwd,
                     db=dbname,
                     charset = "utf8")


c = connection.cursor()

# desc 是mysql 的关键字，所以要用反引号
c.execute(
    '''INSERT INTO sq_course ( name, `desc`, display_idx) VALUES 
    ('法语1','法语课1',10),
    ('法语2','法语课2',10)''')

# 一定要执行commit才能插入成功
connection.commit()

# c.rowcount 指明了这次插入记录的条数
print(c.rowcount)