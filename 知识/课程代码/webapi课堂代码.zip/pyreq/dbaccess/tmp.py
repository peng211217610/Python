import MySQLdb


host = '192.168.0.107'  # 'ci.ytesting.com'，'192.168.0.105'
user="songqin"
passwd="songqin"
dbname="plesson"


connection = MySQLdb.connect(host=host,
                     user=user,
                     passwd=passwd,
                     db=dbname,
                     charset = "utf8")


c = connection.cursor()

# 第一步：从数据文件中读出文件，问问大家该怎么写
with open('courses1.data',encoding='utf8') as f:
    lines = f.read().splitlines()

    for line in lines:
        # 如果不是空行
        if line :
            # 注意 desc 是mysql 的关键字，所以要用反引号
            c.execute(
                  f"""INSERT INTO sq_course ( name, `desc`, display_idx) VALUES ({line})"""
                   )



# 一定要执行commit才能插入成功
connection.commit()

# c.rowcount 指明了这次插入记录的条数
print(c.rowcount)
connection.close()
