import MySQLdb


host = '192.168.0.107'  # 'ci.ytesting.com'，'192.168.0.105'
user="songqin"
passwd="songqin"
dbname="plesson"


connection = MySQLdb.connect(host=host,
                     user=user,
                     passwd=passwd,
                     db=dbname,
                     charset = "utf8")


c = connection.cursor()



# 删除
c.execute("DELETE FROM sq_course WHERE name LIKE '测试课程%'")


# 一定要执行commit才能删除成功
connection.commit()

# c.rowcount 指明了这次删除记录的条数
print(c.rowcount)