host = '192.168.0.105'  # 'ci.ytesting.com'
user="songqin"
passwd="songqin"
dbname="plesson"

import MySQLdb


connection = MySQLdb.connect(host=host,
                     user=user,
                     passwd=passwd,
                     db=dbname,
                     charset = "utf8")

# 返回一个cursor对象
c = connection.cursor()

# 从数据文件中读出文件
with open('courses1.data',encoding='utf8') as f:
    lines = f.read().splitlines()

    for line in lines:
        # 如果不是空行
        if line :
            # 注意 desc 是mysql 的关键字，所以要用反引号
            c.execute(
                  f"""INSERT INTO sq_course ( name, `desc`, display_idx) VALUES ({line})"""
                   )

connection.commit()


# c.execute("DELETE FROM sq_course WHERE name LIKE '测试课程%' ")
# connection.commit()

connection.close()

