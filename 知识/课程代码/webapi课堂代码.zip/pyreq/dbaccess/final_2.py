import requests, pprint, time,traceback



host = '192.168.0.105'  # 'ci.ytesting.com'，'192.168.0.105'
user="songqin"
passwd="songqin"
dbname="plesson"


# 3个参数，根据参数来发送相应的消息
def add_course(name,desc,displayidx):
    payload = {
        'action': 'add_course',
        # 格式化字符串的方式来构造消息
        'data':'''
        {
          "name":"%s",
          "desc":"%s",
          "display_idx":"%s"
        }''' % (name,desc,displayidx)

    }
    # data参数 就是构造消息体的
    response = requests.post("http://localhost/api/mgr/sq_mgr/",
                             data=payload)

    # 获取结果，返回给调用者
    retDict = response.json()
    # 打印出结果
    print(retDict)
    return retDict


def list_course():

    params = {
        'action':'list_course',
        'pagenum':'1', 'pagesize':20
    }
    response = requests.get("http://localhost/api/mgr/sq_mgr/",
                            params=params)
    # 获取结果，返回给调用者
    retDict = response.json()
    pprint.pprint(retDict)

    # 获取结果，返回给调用者
    return retDict



import MySQLdb

connection = MySQLdb.connect(host=host,
                     user=user,
                     passwd=passwd,
                     db=dbname,
                     charset = "utf8")



c = connection.cursor()

# 从数据文件中读出文件，并插入数据库
with open('courses1.data',encoding='utf8') as f:
    lines = f.read().splitlines()

    for line in lines:
        # 如果不是空行
        if line :
            # 注意 desc 是mysql 的关键字，所以要用反引号
            c.execute(
                  f"""INSERT INTO sq_course ( name, `desc`, display_idx) VALUES ({line})"""
                   )

connection.commit()


try:
    # 读出数据库中课程信息
    # 执行一个获取 sq_course 表中所有记录的 sql 语句
    c.execute("""SELECT * FROM sq_course""")

    # fetchall方法可以获取所有的数据信息
    courses_indb = c.fetchall()
    print(courses_indb)

    # 列出课程信息

    beforecall = time.time()
    retDict = list_course()
    aftercall = time.time()

    assert   aftercall-beforecall<2


    # 检查list API 返回的内容是否正确
    assert retDict['retcode'] == 0
    # 数量应该和数据库中一致
    assert retDict['total'] == len(courses_indb)
    assert len(retDict['retlist']) == len(courses_indb)

    # 内容也应该一致，这个怎么写？

    # 先将数据库中列表格式转化为字典格式
    courseTable = {}
    for course in courses_indb:
        courseTable[course[0]] = course


    for apicourse in retDict['retlist']:
        # 根据id获取对应的数据库内容
        dbcourse = courseTable[apicourse['id']]
        assert apicourse['id'] == dbcourse[0]
        assert apicourse['name'] == dbcourse[1]
        assert apicourse['desc'] == dbcourse[2]
        assert apicourse['display_idx'] == dbcourse[3]

except:
    print('执行测试过程中出现异常')
    print(traceback.format_exc())


# 删除添加的课程
c.execute("DELETE FROM sq_course WHERE name LIKE '测试课程%' ")
connection.commit()

connection.close()

print('\n========= test case pass =============')
