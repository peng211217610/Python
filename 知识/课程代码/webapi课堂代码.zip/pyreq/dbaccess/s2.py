host = '192.168.0.105'  # 'ci.ytesting.com'
user="songqin"
passwd="songqin"
dbname="plesson"

import MySQLdb


connection = MySQLdb.connect(host=host,
                     user=user,
                     passwd=passwd,
                     db=dbname,
                     charset = "utf8")

# 返回一个cursor对象
c = connection.cursor()

# 执行一个获取 sq_course 表中所有记录的 sql 语句
c.execute("""SELECT * FROM sq_course""")


numrows = c.rowcount
print("we have %s rows ..." % numrows)


found = False
for x in range(0,numrows):
    # 返回的是一个元组，里面每个元素代表一个字段
    row = c.fetchone()
    print(row)

    courseName = row[1]
    if courseName == 'Python':
        found = True
        break

if found:
    print('找到Python课程，通过')
else:
    print('没有找到，不通过')





