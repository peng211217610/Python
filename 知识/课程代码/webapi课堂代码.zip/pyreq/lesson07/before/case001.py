from webapi import *


# 先登录
loginRet,cookies = login('auto','sdfsdfsdf')
if loginRet["retcode"] != 0:
    raise Exception('认证失败')


# 记录下sessionid
sessionid =cookies['sessionid']

# 先列出课程
coureListBefore = list_course(sessionid)['retlist']

# 再添加一门课程
from datetime import datetime
courseName = f'python_{datetime.now().strftime("%Y-%m-%d_%H:%M:%S")}'
retDict = add_course(courseName,'python语言','2',sessionid)

assert retDict['retcode'] == 0

# 再列出课程
coureListAfter = list_course(sessionid)['retlist']

createCount = len(coureListAfter) - len(coureListBefore)

assert createCount == 1


# 取出，多出来的一门课程对象
newcourse = None
for one in coureListAfter:
    if one not in coureListBefore:
        newcourse = one
        break



# 检查是否是刚刚添加的课程
assert newcourse!=None
assert newcourse['name']== courseName
assert newcourse['desc']=='python语言'
assert newcourse['display_idx']==2


# 清除环境操作

delete_course(newcourse['id'],sessionid)



print('\n========= test case pass =============')

