from webapi import *

tm = TeacherMgr()

# 先登录
tm.login('auto', 'sdfsdfsdf')

# 我们不能直接就 添加老师，要确保有课程

# 这里需不需要再 login了？
cm = CourseMgr(tm.sessionid)

# 要确保课程是唯一的

from datetime import datetime
now = datetime.now().strftime('%Y-%m-%d_%H:%M:%S')
courseName = f'python_{now}'

addCourseRet = cm.add_course(courseName,'python语言','2')
assert addCourseRet['retcode'] == 0



# 先列出老师
teacherListBefore = tm.list_teacher()['retlist']

# 再添加一个老师

# 老师的名字也可能重复，所以
teachername = f'zyz_{now}'
addTeacherRet = tm.add_teacher(teachername,'zyz111','朱元璋','老朱',
               [{"id": addCourseRet['id'], "name": "初中化学"}],
               1)

assert addTeacherRet['retcode'] == 0

# 再列出老师
teacherListAfter = tm.list_teacher()['retlist']

createCount = len(teacherListAfter) - len(teacherListBefore)

assert createCount == 1


# 取出，多出来的老师
newteacher = None
for one in teacherListAfter:
    if one not in teacherListBefore:
        newteacher = one
        break



# 检查是否是刚刚添加的老师
assert newteacher!=None
assert newteacher['id']==addTeacherRet['id']
assert newteacher['realname']== '朱元璋'
assert newteacher['username']==teachername
assert newteacher['desc']== '老朱'
assert newteacher['display_idx']==1


# 清除环境操作

tm.delete_teacher(addTeacherRet['id'])
cm.delete_course(addCourseRet['id'])



print('\n========= test case pass =============')

