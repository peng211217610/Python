from webapi import *


# 先创建类
cm = CourseMgr()

# 先登录
loginRet,cookies = cm.login('auto','sdfsdfsdf')
if loginRet["retcode"] != 0:
    raise Exception('认证失败')




# 先添加一门课程
from datetime import datetime
courseName = f'python_{datetime.now().strftime("%Y-%m-%d_%H:%M:%S")}'
addRet = cm.add_course(courseName,'python语言','2')
assert addRet['retcode'] == 0



# 先列出课程
coureListBefore = cm.list_course()['retlist']

# 再添加一门同名课程
retDict = cm.add_course(courseName,'python语言','2')
assert retDict['retcode'] == 2



# 再列出课程
coureListAfter = cm.list_course()['retlist']




# 检查课程没有变化
assert coureListBefore == coureListAfter


# 清除环境操作
for one in coureListBefore :
    if one['name'] == courseName:
        cm.delete_course(one['id'])



print('\n========= test case pass =============')

