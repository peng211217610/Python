from webapi import *

# 先创建类
cm = CourseMgr()

# 先登录
loginRet,cookies = cm.login('auto','sdfsdfsdf')
if loginRet["retcode"] != 0:
    raise Exception('认证失败')


# 记录下sessionid
sessionid =cookies['sessionid']



# 先列出课程
courseList1 = cm.list_course()['retlist']


# 添加一门课程
from datetime import datetime
courseName = f'python_{datetime.now().strftime("%Y-%m-%d_%H:%M:%S")}'
addRet = cm.add_course(courseName,'python语言','2')
assert addRet['retcode'] == 0



# 再删除课程
courseId = addRet['id']
newCourseName = '新名字'
delRet = cm.delete_course(courseId)
assert delRet['retcode'] == 0


# 再先列出课程
courseList2 = cm.list_course()['retlist']



assert courseList1 == courseList2



print('\n========= test case pass =============')

