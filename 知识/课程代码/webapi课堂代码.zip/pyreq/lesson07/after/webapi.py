import requests,pprint,json

class APIBase:

    def pretty_print_POST(self, req):
        """
        At this point it is completely built and ready
        to be fired; it is "prepared".

        However pay attention at the formatting used in
        this function because it is programmed to be pretty
        printed and may differ from the actual request.
        """
        print('{}\n{}\n{}\n\n{}'.format(
            '-----------START-----------',
            req.method + ' ' + req.url,
            '\n'.join('{}: {}'.format(k, v) for k, v in req.headers.items()),
            req.body,
        ))

        from urllib.parse import unquote
        print(unquote(req.body))



    def login(self, username,password):
        payload = {
            'username': username,
            'password': password
        }
        # data参数 就是构造消息体的
        response = requests.post("http://localhost/api/mgr/loginReq",
                                 data=payload)

        # 获取结果，返回给调用者
        retDict = response.json()
        # 打印出结果
        print(retDict)


        self.sessionid = response.cookies['sessionid']

        return retDict,response.cookies



class  CourseMgr(APIBase):
    def __init__(self,sessionid=None):
        self.sessionid = sessionid

    def add_course(self,name,desc,displayidx):
        payload = {
            'action': 'add_course',
            # 格式化字符串的方式来构造消息
            'data':'''
            {
              "name":"%s",
              "desc":"%s",
              "display_idx":"%s"
            }''' % (name,desc,displayidx)

        }
        # data参数 就是构造消息体的
        response = requests.post("http://localhost/api/mgr/sq_mgr/",
                                 data=payload,
                                 cookies={'sessionid':self.sessionid})



        # 获取结果，返回给调用者
        retDict = response.json()
        # 打印出结果
        print(retDict)


        return retDict




    def list_course(self):

        params = {
            'action':'list_course',
            'pagenum':'1', 'pagesize':20
        }
        response = requests.get("http://localhost/api/mgr/sq_mgr/",
                                params=params,
                                cookies={'sessionid':self.sessionid})
        # 获取结果，返回给调用者
        retDict = response.json()
        pprint.pprint(retDict)

        # 获取结果，返回给调用者
        return retDict



    def modify_course(self,courseid, name,desc,displayidx):
        payload = {
            'action': 'modify_course',
            'id' : courseid,
            # 格式化字符串的方式来构造消息
            'newdata':'''
            {
              "name":"%s",
              "desc":"%s",
              "display_idx":"%s"
            }''' % (name,desc,displayidx)

        }
        # data参数 就是构造消息体的
        response = requests.put("http://localhost/api/mgr/sq_mgr/",
                                 data=payload,
                                 cookies={'sessionid':self.sessionid})



        # 获取结果，返回给调用者
        retDict = response.json()
        # 打印出结果
        print(retDict)


        return retDict

    def delete_course(self,courseid):
        payload = {
            'action': 'delete_course',
            'id': f'{courseid}'
        }

        response = requests.delete("http://localhost/api/mgr/sq_mgr/",
                                   data=payload,
                                   cookies={'sessionid':self.sessionid})

        r = response.json()
        pprint.pprint(r)
        return r





class  TeacherMgr(APIBase):

    def __init__(self,sessionid=None):
        self.sessionid = sessionid

    # 老师教授课程是什么格式，这是重点
    # [{"id":419,"name":"初中数学"},{"id":420,"name":"初中英语"}]
    def add_teacher(self,username,password,realname,
                    desc,courses,display_idx):
        payload = {
            'action': 'add_teacher',
            # 格式化字符串的方式来构造消息
            'data':'''{
                "username":"%s",
                "password":"%s",
                "realname":"%s",
                "desc":"%s",
                "courses":%s,
                "display_idx":%s
            }''' % (username,password,realname,desc,
                    # 这边直接写 courses 为什么不行？
                    json.dumps(courses),
                    display_idx)
        }


        # data参数 就是构造消息体的
        response = requests.post("http://localhost/api/mgr/sq_mgr/",
                                 data=payload,
                                 cookies={'sessionid':self.sessionid})



        # 获取结果，返回给调用者
        retDict = response.json()
        # 打印出结果
        print(retDict)

        return retDict




    def list_teacher(self):

        params = {
            'action':'list_teacher',
            'pagenum':'1',
            'pagesize':20
        }
        response = requests.get("http://localhost/api/mgr/sq_mgr/",
                                params=params,
                                cookies={'sessionid':self.sessionid})
        # 获取结果，返回给调用者
        retDict = response.json()
        pprint.pprint(retDict)

        # 获取结果，返回给调用者
        return retDict

    def modify_teacher(self,teacherid,
                       username, password, realname,
                       desc, courses, display_idx
                       ):
        payload = {
            'action': 'modify_teacher',
            'id' : teacherid,
            # 格式化字符串的方式来构造消息
            'newdata': '''{
                        "username":"%s",
                        "password":"%s",
                        "realname":"%s",
                        "desc":"%s",
                        "courses":%s,
                        "display_idx":%s
                    }''' % (username, password, realname, desc,
                            # 这边直接写 courses 为什么不行？
                            json.dumps(courses),
                            display_idx)
        }


        # response = requests.put( "http://localhost/api/mgr/sq_mgr/",
        #                          data=payload,
        #                          cookies={'sessionid':self.sessionid})

        # data参数 就是构造消息体的
        req = requests.Request('PUT',
                               "http://localhost/api/mgr/sq_mgr/",
                                 data=payload,
                                 cookies={'sessionid':self.sessionid})

        prepared = req.prepare()

        self.pretty_print_POST(prepared)

        s = requests.Session()
        response = s.send(prepared)


        # 获取结果，返回给调用者
        retDict = response.json()
        # 打印出结果
        print(retDict)


        return retDict

    def delete_teacher(self,teacherid):
        payload = {
            'action': 'delete_teacher',
            'id': teacherid
        }

        response = requests.delete("http://localhost/api/mgr/sq_mgr/",
                                   data=payload,
                                   cookies={'sessionid':self.sessionid})

        r = response.json()
        pprint.pprint(r)
        return r


if '__main__' == __name__:
    tm = TeacherMgr()
    tm.login('auto','sdfsdfsdf')

    # tm.modify_teacher(232,'zyz', 'zyz2222', '朱元璋', '老朱',
    #                 [{"id": 1052, "name": "初中化学"}],
    #                 33)

    tm.list_teacher()
    tm.delete_teacher(232)
    tm.list_teacher()

    # # 要确保有这样的 课程
    # tm.add_teacher('zyz','zyz111','朱元璋','老朱',
    #                [{"id": 1052, "name": "初中化学"}],
    #                4)