from webapi import *

# 先创建类
cm = CourseMgr()

# 先登录
loginRet,cookies = cm.login('auto','sdfsdfsdf')
if loginRet["retcode"] != 0:
    raise Exception('认证失败')


# 先添加一门课程
from datetime import datetime
courseName = f'python_{datetime.now().strftime("%Y-%m-%d_%H:%M:%S")}'
addRet = cm.add_course(courseName,'python语言','2')
assert addRet['retcode'] == 0



# 再修改课程名，想想新的课程名用什么
courseId = addRet['id']
newCourseName = '新名字'
modifyRet = cm.modify_course(courseId,newCourseName,'python语言','2')
assert modifyRet['retcode'] == 0


# 再查看新的课程名是否为修改后的课程名


# 列出课程
courseList = cm.list_course()['retlist']


#检查修改后的名字是否正确
newCourse = [course for course in courseList if course['id']==courseId][0]


assert newCourse['name'] == newCourseName

# 清除环境操作
cm.delete_course(courseId)



print('\n========= test case pass =============')

