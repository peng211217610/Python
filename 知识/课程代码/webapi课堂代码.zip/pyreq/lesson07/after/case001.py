from webapi import *


# 先创建类
cm = CourseMgr()

# 先登录
loginRet,cookies = cm.login('auto','sdfsdfsdf')
if loginRet["retcode"] != 0:
    raise Exception('认证失败')



# 先列出课程
coureListBefore = cm.list_course()['retlist']

# 再添加一门课程

from datetime import datetime
courseName = f'python_{datetime.now().strftime("%Y-%m-%d_%H:%M:%S")}'
addRet = cm.add_course(courseName,'python语言','2')
assert addRet['retcode'] == 0

# 再列出课程
coureListAfter = cm.list_course()['retlist']

createCount = len(coureListAfter) - len(coureListBefore)

assert createCount == 1


# 取出，多出来的一门课程对象
newcourse = None
for one in coureListAfter:
    if one not in coureListBefore:
        newcourse = one
        break



# 检查是否是刚刚添加的课程
assert newcourse!=None
assert newcourse['name']== courseName
assert newcourse['desc']=='python语言'
assert newcourse['display_idx']==2


# 清除环境操作

cm.delete_course(newcourse['id'])



print('\n========= test case pass =============')
