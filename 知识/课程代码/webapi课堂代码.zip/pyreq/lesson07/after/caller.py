import sys,os

if len(sys.argv) != 2:
    print('参数错误')
    sys.exit(1)

testcases = sys.argv[1]

tcList = testcases.split(',')

for tc in tcList:
    cmd = f'python {tc}.py'
    print(cmd)
    os.system(cmd)