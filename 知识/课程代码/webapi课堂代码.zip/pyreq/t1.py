import MySQLdb


host = 'ci.ytesting.com'  # 'ci.ytesting.com'，'192.168.0.105'
user="songqin"
passwd="songqin"
dbname="plesson"


connection = MySQLdb.connect(host=host,
                     user=user,
                     passwd=passwd,
                     db=dbname,
                     charset = "utf8")


c = connection.cursor()


with open(
        r'D:\gsync\workspace\sq\WebAPI\pyreq\dbaccess\courses1.data',
        encoding='utf8') \
    as f:
    lines = f.read().splitlines()
    idx = 0
    addbatch = ''
    for line in lines:

        if idx % 10 ==0 :
            if addbatch :
                c.execute(addbatch)
            addbatch = 'INSERT INTO sq_course ( name, `desc`, display_idx) VALUES (%s)' % line
        else:
            addbatch += f', ({line})'

        idx += 1
        print(idx)

    c.execute(addbatch)
# 一定要执行commit才能插入成功
connection.commit()

# c.rowcount 指明了这次插入记录的条数
print(c.rowcount)