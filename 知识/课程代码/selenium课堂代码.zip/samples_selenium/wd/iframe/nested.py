# coding=utf-8
from selenium import webdriver

driver = webdriver.Chrome()

driver.get('file:///D:/gsync/workspace/sq/selenium/samples_selenium/wd/iframe/nested.html')

driver.switch_to.frame('layer2')
driver.switch_to.frame('layer3')

input1 = driver.find_element_by_tag_name("input")
input1.send_keys('输入1')
# print(driver.page_source)
driver.switch_to.default_content()
input1 = driver.find_element_by_tag_name("input")
input1.send_keys('输入2')

input('press any key to quit...')
driver.quit()