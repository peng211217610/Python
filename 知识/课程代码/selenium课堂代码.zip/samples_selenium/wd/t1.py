from selenium import  webdriver
from selenium.webdriver.support.ui  import  Select

driver = webdriver.Chrome()

driver.implicitly_wait(10)


driver.get('https://kyfw.12306.cn/otn/leftTicket/init')


fromEle = driver.find_element_by_id('fromStationText')
fromEle.click()
fromEle.send_keys('南京南\n')



fromEle = driver.find_element_by_id('toStationText')
fromEle.click()
fromEle.send_keys('杭州东\n')


Select(driver.find_element_by_id('cc_start_time'))\
    .select_by_visible_text('06:00--12:00')

driver.find_element_by_css_selector(
    '#date_range li:nth-child(2)'
).click()


xpath = "//*[@id='queryLeftTable']//td[4][@class]/../td[1]//a"

trains = driver.find_elements_by_xpath(xpath)

for t in trains:
    print(t.text)


driver.quit()