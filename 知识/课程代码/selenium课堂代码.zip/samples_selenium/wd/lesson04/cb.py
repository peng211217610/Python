# coding=utf-8
from selenium import webdriver
from selenium.webdriver.common.by import By


driver = webdriver.Chrome(r"d:\tools\webdrivers\chromedriver.exe")

# 打开网址
driver.get('file:///D:/gsync/workspace/sq/selenium/samples_selenium/wd/lesson04/cb.html')

input1 = driver.find_element_by_css_selector("input[value=car]")
# 判断 是否已经选中
selected = input1.is_selected()
if selected:
    print('已经选中，无需点击')
else:
    print('没有选中，需要点击 ')
    input1.click()



input('press any key to quit...')
driver.quit()   # 浏览器退出