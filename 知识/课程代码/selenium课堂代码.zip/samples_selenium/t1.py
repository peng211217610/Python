from selenium import webdriver
driver = webdriver.Chrome(r"d:\tools\webdrivers\chromedriver.exe")
driver.implicitly_wait(10)
# ------------------------
driver.get('http://www.51job.com')


driver.find_element_by_css_selector('a.more').click()



driver.find_element_by_id("kwdselectid").send_keys('python')

driver.find_element_by_id('work_position_input').click()


import time
time.sleep(2)

cityEles = driver.find_elements_by_css_selector('#work_position_click_center_right_list_000000 em')

for one in cityEles:
    cityName = one.text
    classvalue = one.get_attribute('class')

    if cityName == '杭州':
        if classvalue != 'on':
            one.click()
    else:
        if classvalue == 'on':
            one.click()


driver.find_element_by_id('work_position_click_bottom_save').click()


driver.find_element_by_css_selector('.tit').click()


driver.find_element_by_id('funtype_click').click()

driver.find_element_by_id(
    'funtype_click_center_right_list_category_0100_0100'
).click()

driver.find_element_by_id(
    'funtype_click_center_right_list_sub_category_each_0100_0106'
).click()

driver.find_element_by_id('funtype_click_bottom_save').click()



driver.find_element_by_id('cottype_list').click()
driver.find_element_by_xpath("//*[@id='cottype_list']/div/span[2]").click()



driver.find_element_by_id('workyear_list').click()
driver.find_element_by_xpath("//*[@id='workyear_list']/div/span[3]").click()


driver.find_element_by_xpath(
    "//*[@id='saveSearch']/preceding-sibling::span"
).click()


driver.find_element_by_css_selector('div.ush.top_wrap button').click()

jobs = driver.find_elements_by_css_selector('#resultList  div.el')

for job in jobs[1:]:

    spans = job.find_elements_by_tag_name('span')
    fields = [span.text   for  span in spans]
    print('    '.join(fields))



