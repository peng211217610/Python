#coding=utf-8
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import sys

driver=webdriver.Chrome()
driver.get('http://www.51job.com')
search=driver.find_element_by_xpath('//input[@id="kwdselectid"]')
search.send_keys('python')
searchbtn=driver.find_element_by_xpath('//div[@class="ush top_wrap"]/button')
workposition =driver.find_element_by_xpath('//input[@id="work_position_input"]')
default= workposition.get_attribute('value')
workposition.click()

time.sleep(1)

cities=driver.find_elements_by_xpath('//td[@class="js_more"]')

for city in cities:
    if city.text == default:
        key = city.find_element_by_tag_name('em')
        key.click()
    if city.text == "杭州":
        key=city.find_element_by_tag_name('em')
        key.click()

subtn=driver.find_element_by_xpath('//div[@id="work_position_click_bottom"]/span[@id="work_position_click_bottom_save"]')
subtn.click()
searchbtn.click()
content = driver.find_elements_by_xpath('//div[@class="el"]')
for con in content:
    spans=con.find_elements_by_tag_name('span')
    if len(spans) == 5:
        print ("%s | %s | %s | %s | %s" %(spans[0].text, spans[1].text, spans[2].text, spans[3].text, spans[4].text))
driver.quit()