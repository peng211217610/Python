exp = input('请输入表达式:')
print(eval(exp))
