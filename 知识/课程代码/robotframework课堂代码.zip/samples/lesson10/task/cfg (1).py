# coding=utf8
MgrLoginUrl  =      'http://localhost/mgr/login/login.html'
StudentLoginUrl=    'http://localhost/student/login/login.html'

database=           ['127.0.0.1'  , '3306']
adminuser=          {'name':'auto'  ,  'pw':'sdfsdfsdf'}
student1=          {'name':'guanyu'  ,  'pw':'sq888',  'realname':u'关羽'}
